﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment_4_VP
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<string> coll;
      
        public MainWindow()
        {
            InitializeComponent();
            coll = new ObservableCollection<string>();
            string[] s = { "wasay", "Mahad" };
            foreach (string s2 in s)
            {
                coll.Add(s2);
                L1.Items.Add(s2);
            }

            DataContext= this;
        }

        private void b1_Click(object sender, RoutedEventArgs e)
        {
            coll.Add(t2.Text);
            if(L1.Items.Contains(t2.Text))
            {
                MessageBox.Show("Name already in the list ....Please enter a different name");
            }
            else
            {
                L1.Items.Add(t2.Text);
                MessageBox.Show("Player added successfully");
            }
            
            t2.Clear();
      
        }

        private void b2_Click(object sender, RoutedEventArgs e)
        {
            if(L1.SelectedItem != null)
            {
                L1.Items.Remove(L1.SelectedItem.ToString());
            }
            MessageBox.Show("Player removed successfully");
            
        }
    }

    
}